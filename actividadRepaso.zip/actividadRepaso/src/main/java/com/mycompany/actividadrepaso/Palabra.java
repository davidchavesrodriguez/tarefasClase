package com.mycompany.actividadrepaso;

public class Palabra {

    // Atributos
    private String palabra, grafia, lema, definicion;

    // Constructores
    public Palabra() {
    }

    public Palabra(String palabra, String grafia, String lema, String definicion) {
        this.palabra = palabra;
        this.grafia = grafia;
        this.lema = lema;
        this.definicion = definicion;
    }

    // Métodos
    public String getPalabra() {
        return palabra;
    }

    public void setPalabra(String palabra) {
        this.palabra = palabra;
    }

    public String getGrafia() {
        return grafia;
    }

    public void setGrafia(String grafia) {
        this.grafia = grafia;
    }

    public String getLema() {
        return lema;
    }

    public void setLema(String lema) {
        this.lema = lema;
    }

    public String getDefinicion() {
        if (definicion != null) {
            return definicion.replace(".", "./n");
        }
        return "";
    }

    public void setDefinicion(String definicion) {
        this.definicion = definicion;
    }
}
