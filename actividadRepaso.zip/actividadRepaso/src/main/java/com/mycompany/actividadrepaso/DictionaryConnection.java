/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.actividadrepaso;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author A22DavidCR
 */
public class DictionaryConnection {

    public static final String JDBC_DRIVER = "org.sqlite.JDBC";
    public static final String DB_URL = "C:\\Users\\A22DavidCR\\Downloads\\palabras.sqlite3";

    private Connection conexion;

    public Connection getConnection() {
        try {
            if (conexion == null || conexion.isClosed()) {
                conexion = DriverManager.getConnection(DB_URL);
                System.out.println("Conexion creada");
            }
        } catch (SQLException ex) {
            System.out.println("Erro de conexión");
        }
        return null;
    }
}
