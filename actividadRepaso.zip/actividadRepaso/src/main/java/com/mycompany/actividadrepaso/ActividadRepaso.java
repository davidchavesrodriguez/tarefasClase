package com.mycompany.actividadrepaso;

public class ActividadRepaso {

    public static void main(String[] args) {
        System.out.println("Julio, quéroche!");

        Palabra p1 = new Palabra("Mundo", "Mundo", null, null);
        System.out.println("p1.hashCode() =" + p1.hashCode());
        System.out.println("p1.toString() =" + p1.toString());

        Palabra p2 = new Palabra("Mundo", "Mundo", null, null);
        System.out.println("p2.hashCode() =" + p2.hashCode());
        System.out.println("p2.toString() =" + p2.toString());

        if (p1.equals(p2)) {
            System.out.println("Son iguais");
        } else {
            System.out.println("Non son iguais");
        }
        
        
    }

    
}
